package fjr.collision;
public enum QUAD {
	topLeft, topRight, bottomLeft, bottomRight
}
