package fjr.collision;

import java.util.ArrayList;
import java.util.Random;

//import fjr.collision.SmoothParticleHydrodynamics.Particle;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBuilder;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.CircleBuilder;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextBuilder;
import javafx.stage.Stage;
import javafx.util.Duration;

public class BilliardBallDetection extends Application {

	ArrayList<Particle> listParticle;
	ArrayList<Group> listCircle;

	static double xwidth = 400;
	static double ywidth = 400;

	double timeStep = 0.5;
	double numberParticle = 15;
	Random rand = new Random();

	double dmin = 45.0;

	static double xmax = 200.0;
	static double xmin = 0.0;
	static double ymax = 200.0;
	static double ymin = 0.0;
	static double size = 0.0;

	double radius = 15;

	double dmax = 0.0;

	double vmax = 3.0;

	static double xFactor = (xwidth - 0.0) / (xmax - xmin);
	static double yFactor = (ywidth - 0.0) / (ymax - ymin);

	Timeline animation;
	Button buttonPause, buttonPlay;

	static Group drawer;

	Random random = new Random();

	static ArrayList<Color> listColor = new ArrayList<>();

	int iterasi = 0;

	static int indexColor = 0; 
	@Override
	public void start(Stage primarySrage) throws Exception {
		drawer = new Group();
		listColor.add(Color.DARKBLUE);
		listColor.add(Color.ANTIQUEWHITE);
		listColor.add(Color.AQUAMARINE);
		listColor.add(Color.MAGENTA);
		listColor.add(Color.MAROON);
		listColor.add(Color.MEDIUMORCHID);
		listColor.add(Color.MEDIUMSEAGREEN);
		listColor.add(Color.MEDIUMSLATEBLUE);
		listColor.add(Color.PALEGOLDENROD);
		listColor.add(Color.LAWNGREEN);

		generateParticle();
		removeOverlap(listParticle);
		generateCircle();

		for (int i = 0; i < listCircle.size(); i++) {
			Group c = listCircle.get(i);
			drawer.getChildren().add(c);
		}
		//
		addParticleToNode();
		// drawGrid();

		animation = new Timeline();
		animation.setCycleCount(Timeline.INDEFINITE);
		animation.setAutoReverse(false);

		KeyFrame kf = new KeyFrame(Duration.millis(30),
				new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						timeIntegration();
						redrawCircle();
						iterasi++;
						if (iterasi % 30 == 0) {
							removeGrid();
							addParticleToNode();
//							drawGrid();
							iterasi = 0;
						}
					}
				});

		animation.getKeyFrames().add(kf);

		drawer.getChildren().addAll(
				buttonPlay = ButtonBuilder.create().text("PLAY")
						.onAction(new EventHandler<ActionEvent>() {
							@Override
							public void handle(ActionEvent arg0) {
								animation.play();
							}
						}).translateX(10).translateY(10).build(),
				buttonPause = ButtonBuilder.create()

				.text("PAUSE").translateX(80).translateY(10)
						.onAction(new EventHandler<ActionEvent>() {
							@Override
							public void handle(ActionEvent arg0) {
								animation.pause();
							}
						}).build()

		);
		buttonPlay.toFront();
		buttonPause.toFront();
		primarySrage.setScene(new Scene(drawer, xwidth, ywidth));
		primarySrage.show();
	}

	private void redrawCircle() {
		for (int i = 0; i < listCircle.size(); i++) {
			Group c = listCircle.get(i);
			Particle p = listParticle.get(i);
			double x = p.x * xFactor;
			double y = p.y * yFactor;
			c.setTranslateX(x);
			c.setTranslateY(y);
		}
	}

	private void timeIntegration() {
		updatePositions(0.5 * timeStep);
		checkBoundary();
		correctTooCLose();
		calculateCollision();
		updatePositions(0.5 * timeStep);
	}

	ArrayList<Rectangle> listRectangle;

	private void drawGrid() {
		for (int i = 0; i < listParticle.size(); i++) {
			Particle p = listParticle.get(i);
			Rectangle rect = new Rectangle(p.left, p.bottom, p.right, p.top);
			rect.setFill(null);
			rect.setStroke(listColor.get(rand.nextInt(listColor.size())));
			rect.setStrokeWidth(5.0);
			drawer.getChildren().add(rect);
		}
	}

	private void removeGrid() {
		for (int i = drawer.getChildren().size() - 1; i >= 0; i--) {
			if (drawer.getChildren().get(i) instanceof Rectangle) {
				drawer.getChildren().remove(i);
			}
		}
	}

	private void generateCircle() {
		listCircle = new ArrayList<>();

		for (int i = 0; i < listParticle.size(); i++) {
			Particle p = listParticle.get(i);
			double x = p.x * xFactor;
			double y = p.y * yFactor;
			double radius_ = 0.0;
			if (xFactor > yFactor)
				radius_ = radius * xFactor;
			else
				radius_ = radius * yFactor;
			Circle c = CircleBuilder.create().radius(radius_)
					.fill(Color.GAINSBORO)
					.stroke(Color.MAROON)
					.build();
			Font f = Font.font("Arial", FontWeight.BOLD, 16.0);
			Text text = TextBuilder.create().text(Integer.toString(i)).font(f)
					.build();
			Group group = new Group();
			group.setTranslateX(x);
			group.setTranslateY(y);
			group.getChildren().addAll(c,text);

			listCircle.add(group);
		}
	}

	private void generateParticle() {
		listParticle = new ArrayList<>();
		for (int i = 0; i < numberParticle; i++) {
			Particle particle = new Particle(rand.nextDouble() * xmax,
					rand.nextDouble() * ymax, rand.nextDouble() * vmax,
					rand.nextDouble() * vmax);
			listParticle.add(particle);
		}
	}

	private void calculateCollision() {
		for (int i = 0; i < listParticle.size(); i++) {
			Particle p1 = listParticle.get(i);
			for (int j = i + 1; j < listParticle.size(); j++) {
				Particle p2 = listParticle.get(j);
				chekCollision(p1, p2);
			}
		}
	}

	public void chekCollision(Particle p1, Particle p2) {

		if (isOverlap(p1, p2)) {

			double deltaX = p1.x - p2.x;
			double deltaY = p1.y - p2.y;
			double distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);

			deltaX = deltaX / distance;
			deltaY = deltaY / distance;

			double aci = p1.vx * deltaX + p1.vy * deltaY;
			double bci = p2.vx * deltaX + p2.vy * deltaY;

			double acf = bci;
			double bcf = aci;

			p1.vx = p1.vx + (acf - aci) * deltaX;
			p1.vy = p1.vy + (acf - aci) * deltaY;
			p2.vx = p2.vx + (bcf - bci) * deltaX;
			p2.vy = p2.vy + (bcf - bci) * deltaY;
		}
	}

	private void updateVelocity(double dt) {
		for (int i = 0; i < listParticle.size(); i++) {
			Particle p = listParticle.get(i);
			p.vx = p.vx + p.ax * dt;
			p.vy = p.vy + p.ay * dt;
		}
	}

	private void updatePositions(double dt) {
		for (int i = 0; i < listParticle.size(); i++) {
			Particle p = listParticle.get(i);
			p.x += p.vx * dt;
			p.y += p.vy * dt;
		}
	}

	public void removeOverlap(ArrayList<Particle> list) {
		for (int i = 0; i < list.size(); i++) {
			Particle p1 = list.get(i);
			for (int j = list.size() - 1; j > i; j--) {
				Particle p2 = list.get(j);
				if (isOverlap(p1, p2))
					list.remove(j);
			}
		}

		for (int i = list.size() - 1; i >= 0; i--) {
			Particle p1 = list.get(i);
			if (p1.x > xmax - radius || p1.x < xmin + radius
					|| p1.y > ymax - radius || p1.y < ymin + radius) {
				list.remove(i);
			}
		}
	}

	private void correctTooCLose() {
		for (int i = 0; i < listParticle.size(); i++) {
			Particle p1 = listParticle.get(i);
			for (int j = i + 1; j < listParticle.size(); j++) {
				Particle p2 = listParticle.get(j);
				if (isOverlap(p1, p2)) {
					double dx = p1.x - p2.x;
					double dy = p1.y - p2.y;
					p1.x += dx * 0.01;
					p1.y += dy * 0.01;
					p2.x -= dx * 0.01;
					p2.y -= dy * 0.01;
				}
			}
		}
	}

	Node noderoot;

	private void addParticleToNode() {
		noderoot = new Node(0.0, ymax, xmax, 0.0);
		for (int i = 0; i < listParticle.size(); i++) {
			noderoot.insertParticle(listParticle.get(i));
		}
	}

	public void checkBoundary() {
		for (int i = 0; i < listParticle.size(); i++) {
			Particle p = listParticle.get(i);
			if (p.x > xmax - radius)
				p.vx = -Math.abs(p.vx);
			if (p.x < xmin + radius)
				p.vx = Math.abs(p.vx);
			if (p.y > ymax - radius)
				p.vy = -Math.abs(p.vy);
			if (p.y < ymin + radius)
				p.vy = Math.abs(p.vy);
		}
	}

	private boolean isOverlap(Particle p1, Particle p2) {
		double deltax = p1.x - p2.x;
		double deltay = p1.y - p2.y;
		if (deltax * deltax + deltay * deltay < 4 * radius * radius)
			return true;
		return false;
	}

	public static void main(String[] args) {
		launch(args);
	}

}
