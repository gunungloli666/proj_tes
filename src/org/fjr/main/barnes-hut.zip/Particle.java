package fjr.collision;
public  class Particle {
	
	double x = 0.0;
	double y = 0.0;
	double vx = 0.0;
	double vy = 0.0;
	double ax = 0.0;
	double ay = 0.0;
	
	double left = 0.0; 
	double right = 0.0; 
	double top = 0.0;
	double bottom = 0.0; 

	public Particle(double x, double y, double vx, double vy) {
		this.x = x;
		this.y = y;
		this.vx = vx;
		this.vy = vy;
	}

	/*
	 * digunakan untuk menggambar grid dari node untuk kasus barnes-hut algorithm
	 * 
	 */
	public void setGridLine(double left, double top, 
			double right,double bottom) {
		this.left = left;
		this.bottom = bottom;
		this.right = right;
		this.top = top;
	}
}