package fjr.collision;

import java.util.Random;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class Node {

	Particle[] listParticle;
	Particle particle;

	Node nodeTopLeft, nodeTopRight, nodeBottomLeft, nodeBottomRight;

	double topMargin = 0.0;
	double bottomMargin = 0.0;
	double leftMargin = 0.0;
	double rightMargin = 0.0;

	double CenterOfMass[] = new double[3];

	int numberOfParticle;
	
	static Random rand = new Random(); 
	


	public Node(double left, double top, double right, double bottom) {
		leftMargin = left;
		rightMargin = right;
		topMargin = top;
		bottomMargin = bottom;
		numberOfParticle = 0;
		nodeBottomLeft = nodeBottomRight = nodeTopLeft = nodeTopRight = null;
		double x = BilliardBallDetection.xFactor; 
		double y = BilliardBallDetection.yFactor; 
		
		
		Rectangle rect = new Rectangle(leftMargin *x,
				bottomMargin *y , (rightMargin  - leftMargin)* x  , (topMargin  - bottomMargin)* y);
		rect.setFill(null);
		rect.setStroke(BilliardBallDetection.listColor.
				get(rand.nextInt(BilliardBallDetection.listColor.size())));
		rect.setStrokeWidth(3.0);
		BilliardBallDetection.drawer.getChildren().add(rect); 
	}

	public void insertParticle(Particle p) {
		
//		System.out.println("Insert Particle, Jumlah partikel: "+numberOfParticle+ " | "
//		+hashCode() + " | "+p.hashCode()); 
		QUAD q;
		if (numberOfParticle > 1) {
//			System.out.println("Jumlah partikel lebih dari satu | "+hashCode() + " | " + p.hashCode()); 
			q = getQuadran(p);
			insertParticleToQuadran(q, p);
		} else if (numberOfParticle == 1) {
//			System.out.println("Jumlah partikel satu | "+hashCode() + " | " + p.hashCode()); 
			q = getQuadran(particle);
			insertParticleToQuadran(q, particle);
			q = getQuadran(p);
			insertParticleToQuadran(q, p);
		} else if (numberOfParticle == 0) {
			particle = p;
//			System.out.println("setup partikel:===================================== "); 
//			System.out.println("Jumlah partikel nol | "+hashCode() + " | " +p.hashCode()); 
			p.setGridLine(leftMargin, topMargin, rightMargin,
					bottomMargin);
			if((rightMargin - leftMargin)!= (topMargin - bottomMargin)){
				System.out.println("Something wrong"); 
//				System.exit(0);
			}
		}
		numberOfParticle++;
	}

	private void insertParticleToQuadran(QUAD q, Particle particle) {
		switch (q) {
		case topLeft:
			insertTopLeftNode(particle);
			break;
		case topRight:
			insertTopRightNode(particle);
			break;
		case bottomLeft:
			insertBottomLeftNode(particle);
			break;
		case bottomRight:
			insertBottomRightNode(particle);
			break;
		}
	}

	private void insertTopRightNode(Particle p) {
		double leftMargin_ = (leftMargin + rightMargin) / 2.0;
		double rightMargin_ = rightMargin;
		double topMargin_ = topMargin;
		double bottomMargin_ = (bottomMargin + topMargin) / 2.0;

		if (nodeTopRight == null) {
			nodeTopRight = new Node(leftMargin_, topMargin_, rightMargin_,
					bottomMargin_);
		}
		nodeTopRight.insertParticle(p);
	}

	private void insertTopLeftNode(Particle p) {
		double leftMargin_ = leftMargin;
		double topMargin_ = topMargin;
		double rightMargin_ = (leftMargin + rightMargin) / 2.0;
		double bottomMargin_ = (bottomMargin + topMargin) / 2.0;
		if (nodeTopLeft == null) {
			nodeTopLeft = new Node(leftMargin_, topMargin_, rightMargin_,
					bottomMargin_);
		}
		nodeTopLeft.insertParticle(p);
	}

	private void insertBottomRightNode(Particle p) {
		double leftMargin_ = (leftMargin + rightMargin) / 2.0;
		double rightMargin_ = rightMargin;
		double bottomMargin_ = bottomMargin;
		double topMargin_ = (bottomMargin + topMargin) / 2.0;

		if (nodeBottomRight == null) {
			nodeBottomRight = new Node(leftMargin_, topMargin_, rightMargin_,
					bottomMargin_);
		}
		nodeBottomRight.insertParticle(p);
	}

	private void insertBottomLeftNode(Particle p ) {
		double leftMargin_ = leftMargin;
		double topMargin_ = (topMargin + bottomMargin) / 2.0;
		double rightMargin_ = (rightMargin + leftMargin) / 2.0;
		double bottomMargin_ = bottomMargin;
		if (nodeBottomLeft == null) {
//			System.out.println("node bottom left  == null"); 
			nodeBottomLeft = new Node(leftMargin_, topMargin_, rightMargin_,
					bottomMargin_);
		}
		nodeBottomLeft.insertParticle(p);
	}

	public QUAD getQuadran(Particle particle) {
		double mx = (leftMargin + rightMargin) / 2.0;
		double my = (bottomMargin + topMargin) / 2.0;
		if (particle.x < mx) {
			if (particle.y < my){
//				System.out.println("Quadran: "+ hashCode() + " | "+particle.hashCode() + " | bottom left"); 
				return QUAD.bottomLeft;
			}
			else{
//				System.out.println("Quadran: "+hashCode()+" | "+particle.hashCode() + " | top left"); 
				return QUAD.topLeft;
			}
		} else {
			if (particle.y < my){
//				System.out.println("Quadran: "+hashCode()+" | "+particle.hashCode() + " | bottom right"); 
				return QUAD.bottomRight;
			}
			else{
//				System.out.println("Quadran: "+hashCode() + " | "+particle.hashCode() + " | top right"); 
				return QUAD.topRight;
			}
		}
	}

}
